package com.fastfood;

public interface ContactDAO {
	//insert Contact interface Here 
    public boolean addContact(ContactDtls cd);
}